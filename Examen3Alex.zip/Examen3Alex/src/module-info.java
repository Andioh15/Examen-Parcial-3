/**
 * 
 */
/**
 * 
 */
module Examen3Alex {
	requires java.desktop;
}